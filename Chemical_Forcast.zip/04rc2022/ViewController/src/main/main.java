package main;

import javax.faces.event.ActionEvent;

import model.entity.AppModuleImpl;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;

import oracle.adf.view.rich.component.rich.data.RichColumn;
import oracle.adf.view.rich.component.rich.data.RichTable;
import oracle.adf.view.rich.component.rich.input.RichInputListOfValues;

import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.jbo.ApplicationModule;
import oracle.jbo.Row;
import oracle.jbo.ViewObject;

public class main

  
{
  
    private RichInputListOfValues yearsSearch;
    private RichInputListOfValues monthsSearch;
    private RichTable viewSearch;


    public main()
    {
    }
    public ApplicationModule getAppM(){
           DCBindingContainer bindingContainer =
               (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
           //BindingContext bindingContext = BindingContext.getCurrent();
           DCDataControl dc =
               bindingContainer.findDataControl("AppModuleDataControl"); // Name of application module in datacontrolBinding.cpx
           AppModuleImpl appM = (AppModuleImpl)dc.getDataProvider();
           return appM;
       }
       AppModuleImpl appM = (AppModuleImpl)this.getAppM();
    

 

    public void customsSave(ActionEvent actionEvent) {
        // Add event code here...
        String yea ="";
        String mon ="";
        String monYear ="";
        //int Id=0;
           
            try{        yea = this.getYearsSearch().getValue().toString();
                        mon= this.getMonthsSearch().getValue().toString();
                        System.out.println("__________ year______"+yea);
                        System.out.println("__________ month______"+ mon);
                
                    }catch(Exception e){
                               yea = " ";
                               mon =" ";
                          }

        ViewObject detaisVo;
        detaisVo = appM.getViewObj1();

        detaisVo.setNamedWhereClauseParam("ab", yea );
         detaisVo.setNamedWhereClauseParam("bc", mon);
          detaisVo.executeQuery();
        AdfFacesContext.getCurrentInstance().addPartialTarget(viewSearch);
          monYear= detaisVo.getCurrentRow().getAttribute("Comb").toString();
                            
                          ViewObject  HeaderVo = appM.getXxInvChemicalCoverHVO1();
                          HeaderVo.getCurrentRow().setAttribute("Daymonth",monYear);
                   appM.getDBTransaction().commit();
      
    }


    public void setYearsSearch(RichInputListOfValues yearsSearch) {
        this.yearsSearch = yearsSearch;
    }

    public RichInputListOfValues getYearsSearch() {
        return yearsSearch;
    }

    public void setMonthsSearch(RichInputListOfValues monthsSearch) {
        this.monthsSearch = monthsSearch;
    }

    public RichInputListOfValues getMonthsSearch() {
        return monthsSearch;
    }


    public void setViewSearch(RichTable viewSearch) {
        this.viewSearch = viewSearch;
    }

    public RichTable getViewSearch() {
        return viewSearch;
    }
}
